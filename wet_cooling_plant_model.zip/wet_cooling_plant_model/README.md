# 厂内湿冷二次循环子模型（600 MW）

打包日期：2026-09-28

## 对象
循环供水湿冷：市政补给 → 冷却塔集水池 → 循泵抽水 → 凝汽器 → 冷却塔 → 落回同一座池。
无独立补水箱、无前池。补给只补蒸发+排污+风吹。出力为外生典型工作日 50%–100% Pe。

## 代码 src/
- params.py            参数与 UA 标定
- submodels.py         集水池、补给阀、循泵、损失、凝汽器、背压降额
- load_profile.py      24 h 调度出力曲线（算例假设）
- simulate_cooling_unit.py  仿真主程序
- plot_cooling_unit.py      作图
- run_600mw_basin.py / scan_cooling_assumptions.py  历史扫描脚本

运行：
```
cd src
python simulate_cooling_unit.py --t_end 86400 --dt 5 --tag 600MW_24h
python plot_cooling_unit.py --stem 600MW_24h
```

## 方案 docs/
- WP1_mechanism.md  当前运行机理方程
- wet_cooling_workflow_vs_model.md  规范/流程对照
- WP1_modeling.md, WP1_literature_check.md, wp1_wet_cooling.md  建模与文献

## 主结果
- results/cooling_unit/unit_600MW_24h.{csv,json}
- figures/wp1_600MW_24h.png
- 其余 unit_600MW_* 为满发/τ 扫描等过程结果
