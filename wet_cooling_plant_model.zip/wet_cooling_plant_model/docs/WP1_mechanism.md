# WP1 湿冷二次循环：运行机理（600 MW 单机）

对象：**循环供水湿冷**。循环水由循泵从**冷却塔集水池**抽出，经凝汽器后回塔，冷却后落回同一座集水池。  
**不建**独立补水箱，**不建**泵房前池。补给只补蒸发+排污+风吹，直接进集水池。  
本阶段只建运行机理，**不计算**早期预警、SUET、ASW。

出力为外生典型工作日曲线（夜间约 50% \(P_e\)，晚高峰 100% \(P_e\)），模拟并网 AGC 调峰，**不是** 24 h 满发。曲线为算例假设，非标准强制表。\(Q_{\mathrm{cond}}(t)=\lambda P(t)\)。

## 物质与水力

循环量 \(m_{cw}\) 在池—泵—凝汽器—塔之间闭合。池容积变化只来自补给与损失：

\[
A_p\,\dot H_p = q_m - q_L,\qquad
q_L = \frac{Q_{\mathrm{cond}}}{\rho h_{fg}}(1+\beta) + \delta\, m_{cw}
\]

\(q_m\)：市政压头高于池位时，液位阀向集水池补水。  
\(m_{cw}=m_{cw}^0\) 当 \(H_p>H_{\mathrm{sub}}+\Delta\)；淹没不足则降额，低于 \(H_{\mathrm{sub}}\) 停泵。

主算例：\(\tau=12\,\mathrm{min}\)，\(V_p=m_{cw}^0\tau\)，\(H_p^0=3\,\mathrm{m}\)。

## 热力

出塔水温 \(\approx T_{\mathrm{wb}}+\mathrm{approach}\)。凝汽器 ε-NTU：

\[
T_{\mathrm{sat}}=T_{\mathrm{in}}+\frac{Q_{\mathrm{cond}}}{\varepsilon C_{cw}},\quad
p_b=p_{\mathrm{sat}}(T_{\mathrm{sat}}),\quad
k_p=1-\alpha(p_b-p_b^0)_+
\]

\(Q_{\mathrm{cond}}=\lambda P\)（\(\lambda=1.50\)，\(\alpha=0.008\,\mathrm{kPa}^{-1}\)）。

## 设计点（满发、补给正常）

仿真给出：\(p_b\approx 5\,\mathrm{kPa}\)，\(q_L/m_{cw}\sim 2\%\) 量级，\(q_m\approx q_L\)，池位稳定。
