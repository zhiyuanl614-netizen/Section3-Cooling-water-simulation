# WP1 单机湿冷闭式循环：显式建模说明

**对象：** 一台凝汽式机组的厂内湿冷闭式循环（水–热–电）。  
**实现：** `src/params.py`、`src/submodels.py`、`src/simulate_cooling_unit.py`。  
**不算入本包：** 市政管网水力、电网潮流与再调度。市政只作为补水压头的外生边界。  
**算例机组：** IEEE-30 bus 2，\(P_g=60.97\,\mathrm{MW}\)，\(P_{\max}=80\,\mathrm{MW}\)（`data/ieee30/gen.csv`）。

支撑分四类，文中逐式标明：

| 标记 | 含义 |
|---|---|
| **[S]** | 国家/行业标准：取值或取值区间 |
| **[L]** | 公开文献或经典传热/流体公式 |
| **[E]** | 工程代表值或控制器整定（无现场数据，不影响失效判据量级） |
| **[C]** | 由额定工况反标定，保证稳态自洽 |

无现场测量时，**因果链与时间量级**优先于绝对容积。凡属 **[E]** 的，不得写成规范强制条文。

---

## 1. 物理对象与假设

湿冷闭式循环：循环水在凝汽器吸热，经冷却塔向大气散热后回到集水池；**循环主体封闭**，离开系统的只有冷却塔蒸发、风吹和为维持浓缩倍率的排污。补充水来自市政，经高位补水箱重力补入集水池。结构与 GB/T 50102—2014 对敞开式循环冷却“用水设备—冷却塔—集水设施—循环水泵—补充水”的系统组成一致 **[S-1]**。

假设（须在论文 Limitations 列出）：

1. 集总参数，补水箱、集水池各一个水位。  
2. 循环水泵额定工况为定流量；仅淹没不足时线性降额。  
3. 冷却塔出塔水温用“湿球+冷幅”，不联立 Merkel 焓差方程。  
4. 热负荷 \(Q_{\mathrm{cond}}=\lambda P\)，\(\lambda\) 为凝汽器热负荷与机械功率之比的工程近似。  
5. 影响以该机出力/少发衡量，不含频率。  
6. 市政压头低于阈值则补水流量为零（弱耦合，水量不回写管网）。

---

## 2. 符号

| 符号 | 单位 | 含义 |
|---|---|---|
| \(H_t,H_p\) | m | 补水箱、集水池水位 |
| \(A_t,A_p\) | m² | 箱、池底面积 |
| \(q_m,q_g,m_{cw},q_L\) | m³/s | 市政补水、重力补水、循环流量、总损失 |
| \(Q_{\mathrm{cond}}\) | kW | 凝汽器热负荷 |
| \(p_b\) | kPa | 凝汽器背压 |
| \(k_p\) | — | 背压功率修正 |
| \(P,P_g,P_{\max}\) | MW | 实际机械功率、初始出力、额定容量 |

---

## 3. 水侧

### 3.1 市政补水压头（外生）

\[
H_{\mathrm{muni}}(t)=\begin{cases}
H_{\mathrm{muni},0}, & t<t_f\\
H_{\mathrm{muni},0}\max\bigl(0,1-(t-t_f)/t_{\mathrm{ramp}}\bigr), & t\ge t_f
\end{cases}
\tag{1}
\]

WP1 默认 \(t_f=0\)，\(t_{\mathrm{ramp}}=0\)（阶跃断供）。  
\(H_{\mathrm{muni},0}=32\,\mathrm{m}\)，失效阈值 \(H_{\mathrm{muni,min}}=28\,\mathrm{m}\)。

**支撑：** GB 50013—2018 规定用户接管最小服务水头按层数计（一层 10 m，二层 12 m，以上每层 +4 m）**[S-2]**。28 m 约合六层直接供水量级，用作**厂内能否进水的模型阈值**，不是规范对电厂补水的专门条款，属 **[E]** 与管网服务水头的对照取值。

### 3.2 市政 → 补水箱

阀流用孔口公式 \(q=C_v u\sqrt{\Delta H}\) **[L-1]**（Bernoulli / IEC 阀方程的平方根压差形式）：

\[
q_m=\begin{cases}
0, & H_{\mathrm{muni}}<H_{\mathrm{muni,min}}\ \text{或}\ H_{\mathrm{muni}}\le H_t\\
C_{v,m}\,u_t\sqrt{H_{\mathrm{muni}}-H_t}, & \text{否则}
\end{cases}
\tag{2}
\]

\[
u_t=\mathrm{sat}_{[0,1]}\bigl(K_t(H_{t,\mathrm{set}}-H_t)\bigr),\quad
H_t<H_{t,\mathrm{set}}\Rightarrow u_t\ge 0.02
\tag{3}
\]

\(C_{v,m}=0.30\,\mathrm{m}^{2.5}/\mathrm{s}\)，\(K_t=0.5\)，\(u_{\min}=0.02\) 为液位比例控制整定 **[E]**，只影响故障前稳态下垂与补水箱排空节奏（箱容积占厂内储水约 4% 量级），不改变集水池主导的 SUET 量级。

### 3.3 补水箱 → 集水池（重力 + 池位阀）

\[
q_g=\begin{cases}
0, & H_t\le H_{t,\min}\ \text{或}\ H_t+\Delta z\le H_p\\
C_{v,g}\,u_p\sqrt{H_t+\Delta z-H_p}, & \text{否则}
\end{cases}
\tag{4}
\]

\[
u_p=\mathrm{sat}_{[0,1]}\bigl(K_p(H_{p,\mathrm{set}}-H_p)\bigr)
\tag{5}
\]

\(\Delta z=15\,\mathrm{m}\) 为高位布置高差 **[E]**。开度由**集水池液位**决定，实现按池侧净损失补水（过程控制常识，非标准条文）。

### 3.4 循环水泵

额定流量按凝汽器设计温升反推 **[S-1]**。循环水带走热负荷

\[
Q_{\mathrm{cond}}=m_{cw}\rho c_p\Delta T \implies
\frac{m_{cw0}}{P_{\max}}=\frac{\lambda\times 10^3}{\rho c_p\Delta T}.
\tag{6}
\]

取 \(\Delta T=8\,\mathrm{K}\)（GB/T 50102 常用设计温升区间 8–10 K）**[S-1]**，\(\lambda=1.50\)（见 §4.4），\(\rho=1000\,\mathrm{kg/m^3}\)，\(c_p=4.187\,\mathrm{kJ/(kg\cdot K)}\) 得

\[
m_{cw0}/P_{\max}\approx 0.034\ \mathrm{m^3/(s\cdot MW)}.
\]

代码采用 **0.0295 m³/(s·MW)**（约 106 m³/(h·MW)）**[S-1][C]**。与 \(\lambda=1.50\) 联立时额定温升约 9.3 K，落在 8–10 K 区间上沿。bus 2：\(m_{cw0}=2.36\,\mathrm{m^3/s}\)。

淹没与汽蚀：离心泵吸入需足够淹没/NPSH **[L-2]**。模型用池水位作淹没深度：

\[
m_{cw}=\begin{cases}
0, & \text{已跳泵或 }H_p\le H_{\mathrm{sub,min}}\\
m_{cw0}\dfrac{H_p-H_{\mathrm{sub,min}}}{\delta}, & H_{\mathrm{sub,min}}<H_p<H_{\mathrm{sub,min}}+\delta\\
m_{cw0}, & H_p\ge H_{\mathrm{sub,min}}+\delta
\end{cases}
\tag{7}
\]

\(H_{\mathrm{sub,min}}=1.2\,\mathrm{m}\)，\(\delta=0.5\,\mathrm{m}\) **[E]**（泵样本/进水池最小淹没量级，非某一泵的型式试验值）。NPSH 计算函数在代码中保留，**流量判据实际用淹没深度**。bus 2 满发仿真中背压先到保护，**未跳泵**。

### 3.5 循环损失（湿冷塔）

GB/T 50102 将冷却塔水量损失分为蒸发、风吹、排水（排污）**[S-1]**。开式系统补充水量由这三项组成（GB/T 50050 口径一致）**[S-3]**。

蒸发由能量：凝汽器热负荷最终主要经塔蒸发带走，

\[
q_{\mathrm{ev}}=\frac{Q_{\mathrm{cond}}}{h_{fg}\rho},\quad h_{fg}=2400\,\mathrm{kJ/kg}
\tag{8}
\]

（湿冷工况汽化潜热约 2400 kJ/kg，非 100 °C 的 2257 kJ/kg）**[L-3]**。  
这与手册经验 \(q_{\mathrm{ev}}/m_{cw}\approx 0.0016\Delta T\)（\(\Delta T=8\,\mathrm{K}\) → 约 1.3%）同量级 **[S-1]**，本模型用热负荷直接算，使损失随出力变化。

排污维持浓缩倍率 \(N\)：\(q_{\mathrm{bd}}=q_{\mathrm{ev}}/(N-1)\)。取 \(N\approx 3\) 则 \(q_{\mathrm{bd}}/q_{\mathrm{ev}}\approx 0.5\)；代码 `blowdown_ratio=0.52` **[S-1][E]**。

风吹：现代收水器可低于循环量的 0.05% **[S-1]**，

\[
q_{\mathrm{dr}}=0.0005\,m_{cw}.
\tag{9}
\]

\[
q_L=q_{\mathrm{ev}}+q_{\mathrm{bd}}+q_{\mathrm{dr}}.
\tag{10}
\]

额定点总损失约循环量的 2–3%，落在 GB/T 50102 常见总损失区间 **[S-1]**。

### 3.6 水位方程（闭式）

\[
A_t\frac{\mathrm{d}H_t}{\mathrm{d}t}=q_m-q_g
\tag{11}
\]

\[
A_p\frac{\mathrm{d}H_p}{\mathrm{d}t}=q_g+\underbrace{m_{cw}}_{回水}-m_{cw}-q_L=q_g-q_L
\tag{12}
\]

回水 \(\approx m_{cw}\)：闭式循环主体不消耗，仅 \(q_L\) 使池位下降。断补水后 \(q_m=0\)，箱排空后 \(q_g=0\)，则 \(\mathrm{d}H_p/\mathrm{d}t=-q_L/A_p\)。

水位不穿越空池：\(H_t\le 0\) 且右端为负时 \(\dot H_t=0\)（同样对 \(H_p\)）。

### 3.7 集水池容积

DL/T 5339—2018《火力发电厂水工设计规范》规定火电厂水工（含湿冷、补给水、泵房吸水）设计 **[S-4]**。吸水井/集水池有效容积工程上按循环水**数分钟停留**计。本模型取停留 \(\tau=4.1\,\mathrm{min}\)：

\[
A_p=\max\left(80,\ \frac{m_{cw0}\,\tau}{H_{p0}}\right),\quad H_{p0}=3\,\mathrm{m}.
\tag{13}
\]

bus 2：\(A_p=193.5\,\mathrm{m^2}\)，有效容积约 \(580\,\mathrm{m^3}\)。  
**4.1 min 是 Methods 假设**（与火电厂吸水井/集水池数分钟停留的工程惯例同量级，**不是** DL/T 5339 某条强制摘录）。大机组档曾用 \(1700\times 3\,\mathrm{m^3}\) 对应约 4 min。

补水箱 \(A_t=30\,\mathrm{m^2}\)，\(H_{t,\mathrm{set}}=4\,\mathrm{m}\)，容积 120 m³ **[E]**，作事故前仓，不主导 SUET。

### 3.8 进塔水温

\[
T_{\mathrm{out}}=T_{\mathrm{wb}}+\Delta T_{\mathrm{ap}},\quad
T_{\mathrm{cw,in}}=T_{\mathrm{out}}+\tfrac12(1-m_{cw}/m_{cw0})^{+}\,(T_{\mathrm{ret}}-T_{\mathrm{out}})
\tag{14}
\]

\(T_{\mathrm{wb}}=15^\circ\mathrm{C}\)，冷幅 \(\Delta T_{\mathrm{ap}}=5\,\mathrm{K}\)（GB/T 50102 冷幅常用 3–5 K）**[S-1]**。流量不足时出塔温升高为线性惩罚 **[E]**，代替 Merkel 模型。\(m_{cw}=0\) 时取 \(T_{\mathrm{cw,in}}=T_{\mathrm{ret}}\)。

---

## 4. 热力（凝汽器）

### 4.1 ε-NTU（冷凝，流体热容流为循环水）

一侧为凝结（饱和温度近似不变），有效度为

\[
\varepsilon=1-e^{-\mathrm{NTU}},\quad \mathrm{NTU}=\frac{UA}{C_{cw}},\quad C_{cw}=m_{cw}\rho c_p
\tag{15}
\]

**[L-4]**（Kays & London / Incropera 冷凝器 ε-NTU）。

\[
T_{\mathrm{ret}}=T_{\mathrm{cw,in}}+\frac{Q_{\mathrm{cond}}}{C_{cw}}
\tag{16}
\]

\[
T_{\mathrm{sat}}=T_{\mathrm{cw,in}}+\frac{Q_{\mathrm{cond}}}{\varepsilon C_{cw}}
\tag{17}
\]

端差 \(T_{\mathrm{sat}}-T_{\mathrm{ret}}=Q_{\mathrm{cond}}(1/\varepsilon-1)/C_{cw}\)。  
\(m_{cw}\le 10^{-6}\,\mathrm{m^3/s}\)：数值上 \(p_b=\min(50,3p_{b,\mathrm{trip}})\)，\(T_{\mathrm{ret}}=T_{\mathrm{cw,in}}+30\,\mathrm{K}\) **[E]**。

### 4.2 \(UA\) 随流量

管内强制对流 Nu\(\propto Re^{0.8}\)（Dittus–Boelter）**[L-5]**，故

\[
UA=UA_0\left(\frac{m_{cw}}{m_{cw0}}\right)^{0.8}.
\tag{18}
\]

HEI 凝汽器总传热系数常含冷却水流速修正（多 \(\propto\sqrt{v}\)）**[S-5][L-6]**。本模型用 0.8 偏对流关联，与 HEI 的 \(\sqrt{v}\) **不完全相同**，属简化 **[C]**。

\(UA_0\) 由额定点反推 **[C]**：设计背压 \(p_{b0}=5\,\mathrm{kPa}\)（凝汽式机组常见 4–6 kPa / HEI 量级）**[S-5]**，

\[
T_{\mathrm{sat},0}=T_{\mathrm{sat}}(p_{b0}),\quad
\varepsilon_0=\frac{Q_{\mathrm{cond}0}}{C_{cw0}(T_{\mathrm{sat},0}-T_{\mathrm{cw,in}0})},\quad
UA_0=-\ln(1-\varepsilon_0)\,C_{cw0}.
\tag{19}
\]

\(\varepsilon_0\) 限幅在 \([0.05,0.99]\)。

### 4.3 饱和线（Antoine）

水，\(1\)–\(100^\circ\mathrm{C}\) 常用系数 **[L-7]**：

\[
\log_{10}p_{\mathrm{mmHg}}=8.07131-\frac{1730.63}{233.426+T_{\mathrm{^\circ C}}},\quad
p_{\mathrm{kPa}}=0.1333224\,p_{\mathrm{mmHg}}.
\tag{20}
\]

\(p_b=\mathrm{psat}(T_{\mathrm{sat}})\)。

### 4.4 热负荷

\[
Q_{\mathrm{cond}}=\lambda P\times 10^3\ \mathrm{kW},\quad \lambda=1.50\ \text{（默认）}.
\tag{21}
\]

凝汽式冷源损失使 \(Q_{\mathrm{cond}}/P\) 约 1.5–2（电效率 35–40%）**[E]**。默认 \(\lambda=1.50\)；原 1.15 使蒸发偏小、SUET 偏长，已改正。须扫描 \(\lambda\in\{1.15,1.50,1.80\}\)。

跳机后 \(Q_{\mathrm{cond}}\) 按约 20 s 时间常数衰减至 0 **[E]**（排汽残余）。

### 4.5 背压–功率

制造厂背压修正曲线在设计点附近近似线性 **[L-8]**。模型

\[
k_p=\max\bigl(0,\ 1-\alpha(p_b-p_{b0})\bigr),\quad \alpha=0.008\ \mathrm{kPa}^{-1}\ \text{（默认）}.
\tag{22}
\]

\(\alpha\) 为 Methods 假设。默认 **0.8 %/kPa**，对齐 660 MW 试验约 0.7–0.8 %/kPa **[L-8]**；原 2 %/kPa 已改正。扫描 \(\alpha\in\{0.008,0.020\}\)。非出厂曲线。

### 4.6 高背压保护

\[
p_b\ge p_{b,\mathrm{trip}}=15\,\mathrm{kPa}\ \text{持续}\ \tau=3\,\mathrm{s}\ \Rightarrow\text{跳机}.
\tag{23}
\]

15 kPa ≈ 3×设计 5 kPa，低真空保护量级 **[E]**。延时 3 s。默认假设下 bus 2 跳机 7123 s（SUET 118.7 min），最大背压 15.07 kPa，**先于跳泵**。

---

## 5. 电侧（仅本机）

指令满发 \(P_{\mathrm{cmd}}=P_g\)。实际

\[
P(t)=\begin{cases}
0, & \text{已跳机}\\
P_g\,k_p(t), & \text{否则}
\end{cases}
\qquad
P_{\mathrm{lost}}=P_g-P(t).
\tag{24}
\]

无电网、无频率。SUET \(= t_{\mathrm{trip}}-t_f\) 是**厂内满发耐受时间**，不是水网 AET。

可用储水：

\[
\mathrm{ASW}=A_t(H_t-H_{t,\min})+A_p(H_p-H_{\mathrm{sub,min}}).
\tag{25}
\]

---

## 6. 数值积分

显式欧拉，默认 \(\Delta t=1\,\mathrm{s}\)（水力分钟级，1 s 足够）。初值：无故障积分至液位准稳态（比例控制有下垂）**[C]**。

---

## 7. 参数总表（bus 2 运行点）

| 参数 | 值 | 类 |
|---|---|---|
| \(P_g,P_{\max}\) | 60.97, 80 MW | 电网算例 CSV |
| \(m_{cw0}/P_{\max}\) | 0.0295 m³/(s·MW) | [S-1][C] |
| \(m_{cw0}\) | 2.36 m³/s | [C] |
| \(\tau_{\mathrm{pool}}\) | 4.1 min | [S-4] 量级 [C] |
| \(A_p,H_{p0}\) | 193.5 m², 3 m | [C] |
| \(A_t,H_{t,\mathrm{set}},\Delta z\) | 30 m², 4 m, 15 m | [E] |
| \(H_{\mathrm{muni}0},H_{\mathrm{muni,min}}\) | 32, 28 m | [S-2] 对照 [E] |
| \(C_{v,m},C_{v,g},K_t,K_p\) | 0.30, 0.60, 0.5, 0.8 | [E] |
| \(H_{\mathrm{sub,min}},\delta\) | 1.2, 0.5 m | [E] |
| \(h_{fg}\) | 2400 kJ/kg | [L-3] |
| 排污/蒸发 | 0.52 | [S-1] \(N\approx 3\) |
| 风吹 | 0.0005 | [S-1] |
| \(T_{\mathrm{wb}}\), 冷幅 | 15 °C, 5 K | [S-1] |
| \(p_{b0}\), TTD 名义 | 5 kPa, 4 K | [S-5] |
| \(\lambda\) | **1.50**（扫描 1.15/1.50/1.80） | [E] |
| \(UA\) 指数 | 0.8（对照 0.5） | [L-5]；HEI 常 \(\sqrt{v}\) |
| \(\alpha\) | **0.008 /kPa**（扫描 0.008/0.02） | [L-8] 量级 |
| \(p_{b,\mathrm{trip}},\tau\) | 15 kPa, 3 s | [E] |
| \(\rho,c_p\) | 1000 kg/m³, 4.187 kJ/(kg·K) | 物性 |
| Antoine A,B,C | 8.07131, 1730.63, 233.426 | [L-7] |

---

## 8. 额定点校核与假设扫描（bus 2）

无故障设计点（默认 \(\lambda=1.50,\alpha=0.008,UA\propto m^{0.8}\)）：\(p_b=5.00\,\mathrm{kPa}\)（与 \(p_{b0}\) 闭合），循环水温升 \(\Delta T=9.26\,\mathrm{K}\)，总损失约占循环量 2.5%。

断补水满发 SUET（**该假设下的仿真值，非现场**）：**118.7 min**。未跳泵，热力保护先到。

\(\lambda\times\alpha\) 扫描（`results/cooling_unit/assumption_scan.csv`）：

| \(\lambda\) | \(\alpha\) (1/kPa) | SUET (min) | 设计 \(\Delta T\) (K) | 损失/循环量 |
|---|---|---|---|---|
| 1.15 | 0.008 | 155.7 | 7.10 | 1.93% |
| 1.15 | 0.020 | 158.4 | 7.10 | 1.93% |
| **1.50** | **0.008** | **118.7** | 9.26 | 2.50% |
| 1.50 | 0.020 | 120.8 | 9.26 | 2.50% |
| 1.80 | 0.008 | 98.3 | 11.11 | 3.00% |
| 1.80 | 0.020 | 100.1 | 11.11 | 3.00% |

同默认 \(\lambda,\alpha\) 下 \(UA\propto m^{0.5}\)（HEI 流速量级）：SUET **119.5 min**（与 0.8 相差 <1 min）。  
**SUET 对 \(\lambda\) 敏感（蒸发），对 \(\alpha\) 与 \(UA\) 指数不敏感。** 量级均为 **1.5–2.6 h**，链条结论不随系数翻转。

---

## 9. 引用（建模用到的，不扩写未用文献）

**[S-1]** GB/T 50102—2014《工业循环水冷却设计规范》。敞开式循环冷却；蒸发、风吹、排水损失；温升与冷幅常用区间。  
**[S-2]** GB 50013—2018《室外给水设计标准》§3.0.10 最小服务水头。  
**[S-3]** GB/T 50050—2017《工业循环冷却水处理设计规范》开式系统补充水量组成。  
**[S-4]** DL/T 5339—2018《火力发电厂水工设计规范》。火电厂湿冷/补给水/泵房水工设计。  
**[S-5]** Heat Exchange Institute, *Standards for Steam Surface Condensers*（凝汽器传热与设计背压量级）。  

**[L-1]** 孔口/控制阀：\(q=C_v\sqrt{\Delta p}\) 类公式，见控制阀手册与 Bernoulli。  
**[L-2]** Hydraulic Institute / 离心泵 NPSH 与吸入淹没。  
**[L-3]** 水的汽化潜热（冷却塔水温工况）。  
**[L-4]** Kays, W. M. & London, A. L. *Compact Heat Exchangers*；Incropera 等传热教材，冷凝器 ε-NTU。  
**[L-5]** Dittus, F. W. & Boelter, L. M. K. (1930) 管内对流，\(Nu\propto Re^{0.8}\)。  
**[L-6]** 凝汽器总传热系数与冷却水流速（HEI / Berman 类公式，流速修正常为平方根）。  
**[L-7]** Antoine 式，水 1–100 °C 系数（NIST/CRC 常用组）。  
**[L-8]** 汽轮机背压修正曲线；如超超临界机组试验与热平衡（背压每升高 1 kPa 功率变化为 MW 级，近线性段）。  

WP1 仿真入口：`python src/simulate_cooling_unit.py --bus 2 --t_fault 0 --t_end 12000 --dt 1`。
