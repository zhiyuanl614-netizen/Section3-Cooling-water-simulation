"""600 MW 湿冷二次循环（循环供水）运行参数。"""
from dataclasses import dataclass
import numpy as np

_A, _B, _C = 8.07131, 1730.63, 233.426
_MMHG2KPA = 0.1333224


def psat_from_t(T_C):
    return 10.0 ** (_A - _B / (_C + T_C)) * _MMHG2KPA


def tsat_from_p(P_kPa):
    P_mmHg = max(P_kPa, 1e-3) / _MMHG2KPA
    return _B / (_A - np.log10(P_mmHg)) - _C


@dataclass
class Params:
    Pmax_MW: float = 600.0
    Pg_MW: float = 600.0  # 额定点标定 UA；运行出力由 24 h 曲线给出
    # 冷却塔集水池（循环泵由此抽水；无独立补水箱、无前池）
    H_pool_set: float = 3.0
    H_pool0: float = 3.0
    pool_stay_min: float = 12.0          # 池水停留，主算例 12 min
    H_submerge_min: float = 1.2
    submerge_band: float = 0.5
    # 补给：市政→集水池液位阀
    H_muni_head: float = 32.0
    H_muni_min: float = 28.0
    Cv_make: float = 1.50   # 补给能力须覆盖 q_L（600 MW 约 0.58 m³/s）
    Kp_pool: float = 0.8
    # 循环泵 / 循环量
    m_cw0_per_MW: float = 0.0295
    NPSH_r: float = 8.0
    h_suction_fric: float = 1.0
    p_atm_kPa: float = 101.325
    # 塔与损失
    h_fg: float = 2400.0
    blowdown_ratio: float = 0.52
    drift_frac: float = 0.0005
    tower_approach_K: float = 5.0
    T_wetbulb: float = 15.0
    # 凝汽器 / 背压
    p_b0_kPa: float = 5.0
    TTD_K: float = 4.0
    cp_water: float = 4.187
    rho_water: float = 1000.0
    lp_heat_frac: float = 1.50
    UA_exp: float = 0.8
    dPdp_frac_per_kPa: float = 0.008
    p_b_trip_kPa: float = 15.0
    trip_delay_s: float = 3.0

    def __post_init__(self):
        self.m_cw0 = self.m_cw0_per_MW * self.Pmax_MW
        self.Q_cond0 = self.lp_heat_frac * self.Pg_MW * 1000.0
        stay_s = self.pool_stay_min * 60.0
        self.A_pool = max(80.0, self.m_cw0 * stay_s / max(self.H_pool0, 0.5))
        self.V_pool = self.A_pool * self.H_pool0
        evap0 = self.Q_cond0 / self.h_fg / self.rho_water
        self.Q_loss = evap0 + self.blowdown_ratio * evap0 + self.drift_frac * self.m_cw0
        self.C_cw0 = self.m_cw0 * self.rho_water * self.cp_water
        Tsat0 = tsat_from_p(self.p_b0_kPa)
        Tin0 = self.T_wetbulb + self.tower_approach_K
        dT0 = max(Tsat0 - Tin0, 1.0)
        eps0 = min(max(self.Q_cond0 / (self.C_cw0 * dT0), 0.05), 0.99)
        self.UA0 = (-np.log(1 - eps0)) * self.C_cw0
