"""600 MW 湿冷 24 h 运行图。"""
import os, csv, json, argparse
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
fp = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc"
font_manager.fontManager.addfont(fp)
plt.rcParams["font.family"] = font_manager.FontProperties(fname=fp).get_name()
plt.rcParams["axes.unicode_minus"] = False

ap = argparse.ArgumentParser()
ap.add_argument("--stem", default="600MW_24h")
cli = ap.parse_args()
js = json.load(open(os.path.join(ROOT, "results/cooling_unit", f"unit_{cli.stem}.json")))


def load(path):
    d = {}
    with open(path) as f:
        for row in csv.DictReader(f):
            for k, v in row.items():
                d.setdefault(k, []).append(float(v))
    return {k: np.array(v) for k, v in d.items()}


d = load(os.path.join(ROOT, "results/cooling_unit", f"unit_{cli.stem}.csv"))
t = d["t"] / 3600.0
fig, ax = plt.subplots(3, 2, figsize=(10.4, 8.6), sharex=True)
fig.suptitle("600 MW 湿冷二次循环  典型工作日（调度出力 50%–100% $P_e$，补给正常）", fontsize=12)


def v(a):
    a.grid(True, alpha=0.3)
    a.set_xlim(0, 24)
    a.set_xticks([0, 4, 8, 12, 16, 20, 24])
    a.spines["top"].set_visible(False)
    a.spines["right"].set_visible(False)


a = ax[0, 0]
if "P_cmd_MW" in d:
    a.plot(t, d["P_cmd_MW"], color="#95a5a6", lw=1, label="调度指令")
a.plot(t, d["P_MW"], color="#1f6f8b", label="实际出力")
a.set_ylabel("MW")
a.set_title("(a) 机组出力（外生日曲线）")
a.legend(fontsize=8)
v(a)

a = ax[0, 1]
a.plot(t, d["H_pool"], color="#1e8449")
a.set_ylabel("m")
a.set_title("(b) 集水池水位（液位阀跟踪，变幅仅数 cm）")
lo, hi = float(d["H_pool"].min()), float(d["H_pool"].max())
pad = max(0.02, 0.4 * (hi - lo + 1e-6))
a.set_ylim(lo - pad, hi + pad)
v(a)

a = ax[1, 0]
a.plot(t, d["m_cw"], color="#1f6f8b")
a.set_ylabel("m$^3$/s")
a.set_ylim(0, max(d["m_cw"]) * 1.15)
a.set_title("(c) 循泵（定速额定抽水，不随电负荷）")
v(a)

a = ax[1, 1]
a.plot(t, d["q_makeup"], color="#1f6f8b", label="补给 $q_m$")
a.plot(t, d["q_loss"], color="#c0392b", ls="--", label="损失 $q_L$")
a.set_ylabel("m$^3$/s")
a.set_title("(d) 补给与蒸发/排污/风吹")
a.legend(fontsize=8)
v(a)

a = ax[2, 0]
a.plot(t, d["T_cw_in"], color="#1f6f8b", label="进凝汽器")
a.plot(t, d["T_return"], color="#b9770e", label="出凝汽器")
a.set_ylabel("°C")
a.set_xlabel("时刻 (h)")
a.set_title("(e) 循环水温")
a.legend(fontsize=8)
v(a)

a = ax[2, 1]
a.plot(t, d["p_b"], color="#6c3483")
a.set_ylabel("kPa")
a.set_xlabel("时刻 (h)")
a.set_title("(f) 凝汽器背压")
v(a)

fig.tight_layout()
out = os.path.join(ROOT, "figures", f"wp1_{cli.stem}.png")
os.makedirs(os.path.dirname(out), exist_ok=True)
fig.savefig(out, dpi=140, bbox_inches="tight", facecolor="white")
print("wrote", out)
