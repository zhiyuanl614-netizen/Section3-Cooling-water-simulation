"""600 MW 单机湿冷二次循环：单座塔池，无独立补水箱，无电网。"""
import os, csv, json, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from params import Params
from simulate_cooling_unit import run

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "results", "cooling_unit")
os.makedirs(OUT, exist_ok=True)

# 主算例 τ=12 min
p = Params(Pg_MW=600.0, Pmax_MW=600.0, pool_stay_min=12.0, single_basin=True)
s, csvf, _, _ = run(bus=0, Pg=600.0, Pmax=600.0, t_fault=0.0, t_end=25000.0,
                    dt=1.0, p=p, tag="600MW_tau12_tf0")
print("MAIN", s["SAET_min"], "A_pool", s["A_pool"], "csv", s["csv"])

rows = []
for tau in (4.1, 8.0, 12.0, 15.0, 20.0):
    p = Params(Pg_MW=600.0, Pmax_MW=600.0, pool_stay_min=tau, single_basin=True)
    s, _, _, _ = run(bus=0, Pg=600.0, Pmax=600.0, t_fault=0.0, t_end=30000.0,
                     dt=2.0, p=p, tag=f"600MW_tau{tau}_scan")
    rec = dict(tau_min=tau, A_pool_m2=round(s["A_pool"], 1),
               V_pool_m3=round(s["A_pool"] * 3.0, 1),
               SAET_min=None if s["SAET_min"] is None else round(s["SAET_min"], 2),
               t_pump=s["t_pump_trip_s"],
               pb_design=s["design_point"]["p_b_kPa"])
    rows.append(rec)
    print(rec, flush=True)

path = os.path.join(OUT, "600MW_tau_scan.csv")
with open(path, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
json.dump(rows, open(os.path.join(OUT, "600MW_tau_scan.json"), "w"), indent=1)
print("wrote", path)
