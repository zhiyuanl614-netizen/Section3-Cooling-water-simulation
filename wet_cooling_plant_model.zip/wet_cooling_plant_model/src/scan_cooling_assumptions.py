"""WP1 假设扫描：λ × α，以及 UA 指数 0.8 vs 0.5。"""
import os, csv, json, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from params import Params, load_unit_from_gen
from simulate_cooling_unit import run

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "results", "cooling_unit")
os.makedirs(OUT, exist_ok=True)

Pg, Pmax = load_unit_from_gen(2)
rows = []
for lam in (1.15, 1.50, 1.80):
    for alp in (0.008, 0.020):
        for ua in (0.8,):
            p = Params(Pg_MW=Pg, Pmax_MW=Pmax, lp_heat_frac=lam,
                       dPdp_frac_per_kPa=alp, UA_exp=ua)
            s, _, _, _ = run(bus=2, t_fault=0.0, t_end=20000.0, dt=2.0, p=p)
            rec = dict(lambda_Q=lam, alpha_per_kPa=alp, UA_exp=ua,
                       SAET_min=s["SAET_min"], t_pump=s["t_pump_trip_s"],
                       pb_design=s["design_point"]["p_b_kPa"],
                       dT_design=s["design_point"]["dT_K"],
                       loss_frac=s["design_point"]["loss_frac"])
            rows.append(rec)
            print(rec, flush=True)

# HEI-like UA ~ m^0.5 at baseline λ,α
p = Params(Pg_MW=Pg, Pmax_MW=Pmax, lp_heat_frac=1.50,
           dPdp_frac_per_kPa=0.008, UA_exp=0.5)
s, _, _, _ = run(bus=2, t_fault=0.0, t_end=20000.0, dt=2.0, p=p)
rows.append(dict(lambda_Q=1.50, alpha_per_kPa=0.008, UA_exp=0.5,
                 SAET_min=s["SAET_min"], t_pump=s["t_pump_trip_s"],
                 pb_design=s["design_point"]["p_b_kPa"],
                 dT_design=s["design_point"]["dT_K"],
                 loss_frac=s["design_point"]["loss_frac"]))
print("UA0.5", rows[-1], flush=True)

path = os.path.join(OUT, "assumption_scan.csv")
with open(path, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    for r in rows:
        w.writerow({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items()})
json.dump(rows, open(os.path.join(OUT, "assumption_scan.json"), "w"), indent=1)
print("wrote", path)
