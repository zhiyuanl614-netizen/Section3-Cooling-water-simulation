"""600 MW 湿冷二次循环：集水池—循泵—凝汽器—冷却塔。
默认外生 24 h 调度出力（50%–100% Pe），补给正常。
"""
from __future__ import annotations
import os, csv, json, argparse
from params import Params
import submodels as sm
from load_profile import power_MW, HOURLY_FRAC

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "results", "cooling_unit")


def design_point(p):
    Hp = sm.equilibrate_pool(p)
    m_cw = sm.pump_flow(Hp, False, p)
    Tret = p.T_wetbulb + p.tower_approach_K + 8.0
    Tin = sm.basin_temp(Tret, m_cw, p)
    pb, Tret = sm.condenser(m_cw, Tin, p.Q_cond0, p)
    q_mu = sm.makeup_flow(0.0, Hp, p, t_fault=1e12, ramp=0)
    q_L = sm.loss_flow(p.Q_cond0, m_cw, p)
    return dict(
        H_pool_m=Hp, m_cw=m_cw, q_makeup=q_mu, q_loss=q_L,
        T_cw_in_C=Tin, T_return_C=Tret, dT_K=Tret - Tin,
        p_b_kPa=pb, k_p=sm.power_derate(pb, p),
        Q_cond0_kW=p.Q_cond0, UA0=p.UA0,
        V_pool_m3=p.V_pool, A_pool=p.A_pool,
        loss_frac=q_L / max(p.m_cw0, 1e-12),
    )


def run(t_fault=1e12, ramp=0.0, t_end=86400.0, dt=5.0, p=None, tag=None,
        follow_load=True):
    if p is None:
        p = Params()
    Pmax = p.Pmax_MW
    H_pool = sm.equilibrate_pool(p)
    P_cmd = power_MW(0.0, Pmax) if follow_load else p.Pg_MW
    Q_cond = p.lp_heat_frac * P_cmd * 1000.0
    pump_tripped = gen_tripped = False
    t_pump_trip = t_gen_trip = None
    hi_bp_timer = 0.0
    T_return = p.T_wetbulb + p.tower_approach_K + 8.0
    rows = []
    n = int(t_end / dt) + 1
    for i in range(n):
        t = i * dt
        P_cmd = power_MW(t, Pmax) if follow_load else p.Pg_MW
        dHp, m_cw, q_mu, q_L = sm.water_derivs(
            t, H_pool, pump_tripped, p, t_fault, ramp, Q_cond_kW=Q_cond)
        if (not pump_tripped) and H_pool <= p.H_submerge_min:
            pump_tripped = True
            t_pump_trip = t
            m_cw = 0.0
        T_cw_in = sm.basin_temp(T_return, m_cw, p)
        p_b, T_return = sm.condenser(m_cw, T_cw_in, Q_cond, p)
        k_p = sm.power_derate(p_b, p)
        if p_b >= p.p_b_trip_kPa:
            hi_bp_timer += dt
        else:
            hi_bp_timer = 0.0
        if (not gen_tripped) and hi_bp_timer >= p.trip_delay_s:
            gen_tripped = True
            t_gen_trip = t
        P_aff = 0.0 if gen_tripped else P_cmd * k_p
        if gen_tripped:
            Q_cond = max(0.0, Q_cond - dt * p.Q_cond0 / 20.0)
        else:
            Q_cond = p.lp_heat_frac * P_aff * 1000.0
        rows.append(dict(
            t=t, H_pool=H_pool, m_cw=m_cw, q_makeup=q_mu, q_loss=q_L,
            Q_cond_kW=Q_cond, T_cw_in=T_cw_in, T_return=T_return,
            p_b=p_b, k_p=k_p, P_cmd_MW=P_cmd, P_MW=P_aff,
            pump=int(not pump_tripped), gen=int(not gen_tripped)))
        H_pool = max(0.0, H_pool + dt * dHp)

    os.makedirs(OUT, exist_ok=True)
    tag = tag or "600MW_24h"
    csvfile = os.path.join(OUT, f"unit_{tag}.csv")
    keys = list(rows[0].keys())
    step = max(1, int(60.0 / dt))  # 1 min 采样
    with open(csvfile, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        for r in rows[::step]:
            w.writerow({k: (round(r[k], 6) if isinstance(r[k], float) else r[k]) for k in keys})

    dp = design_point(p)
    energy = sum(r["P_MW"] for r in rows) * dt / 3600.0
    summary = dict(
        work_package="WP1-mechanism-24h",
        Pmax_MW=Pmax, follow_load=follow_load,
        load_frac_hourly=[float(x) for x in HOURLY_FRAC],
        pool_stay_min=p.pool_stay_min,
        A_pool=p.A_pool, V_pool_m3=p.V_pool, m_cw0=p.m_cw0,
        design_point={k: (round(float(v), 4) if isinstance(v, (int, float)) else v)
                      for k, v in dp.items()},
        energy_MWh=round(energy, 1),
        P_min_MW=min(r["P_MW"] for r in rows),
        P_max_MW=max(r["P_MW"] for r in rows),
        pb_max=max(r["p_b"] for r in rows),
        pb_min=min(r["p_b"] for r in rows),
        qL_min=min(r["q_loss"] for r in rows),
        qL_max=max(r["q_loss"] for r in rows),
        t_fault_s=t_fault, t_pump_trip_s=t_pump_trip, t_gen_trip_s=t_gen_trip,
        csv=os.path.relpath(csvfile, ROOT),
        note="外生典型工作日出力 50–100% Pe；补给正常；无补水箱/前池；无预警。曲线为算例假设。",
    )
    json.dump(summary, open(os.path.join(OUT, f"unit_{tag}.json"), "w"),
              ensure_ascii=False, indent=1)
    return summary, csvfile, rows, p


def _print(s):
    print("=" * 64)
    print(" 600 MW 湿冷二次循环  典型工作日 24 h")
    print("=" * 64)
    print(f"  出力范围  {s['P_min_MW']:.1f} – {s['P_max_MW']:.1f} MW")
    print(f"  日电量    {s['energy_MWh']:.0f} MWh  (满发日 14400)")
    print(f"  集水池    V={s['V_pool_m3']:.0f} m3  τ={s['pool_stay_min']} min")
    print(f"  背压      {s['pb_min']:.2f} – {s['pb_max']:.2f} kPa")
    print(f"  损失 qL   {s['qL_min']:.3f} – {s['qL_max']:.3f} m3/s")
    print("=" * 64)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--t_fault", type=float, default=1e12)
    ap.add_argument("--t_end", type=float, default=86400.0)
    ap.add_argument("--dt", type=float, default=5.0)
    ap.add_argument("--tag", type=str, default="600MW_24h")
    ap.add_argument("--stay", type=float, default=12.0)
    ap.add_argument("--constant", action="store_true")
    a = ap.parse_args()
    p = Params(pool_stay_min=a.stay)
    s, _, _, _ = run(t_fault=a.t_fault, t_end=a.t_end, dt=a.dt, p=p,
                     tag=a.tag, follow_load=not a.constant)
    _print(s)
