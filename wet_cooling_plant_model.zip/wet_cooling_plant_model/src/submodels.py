"""湿冷二次循环运行子模型：集水池 + 循泵 + 凝汽器 + 冷却塔。
循环水由循泵从集水池抽出 → 凝汽器 → 回塔 → 落回集水池。
补给只补蒸发+排污+风吹，直接进集水池。
"""
import numpy as np
from params import psat_from_t


def muni_head(t, p, t_fault, ramp=0.0):
    if t < t_fault:
        return p.H_muni_head
    if ramp <= 0:
        return 0.0
    return p.H_muni_head * max(0.0, 1.0 - (t - t_fault) / ramp)


def makeup_flow(t, H_pool, p, t_fault, ramp):
    """市政补给 → 集水池（液位比例阀）。"""
    head = muni_head(t, p, t_fault, ramp)
    if head < p.H_muni_min:
        return 0.0
    driving = head - H_pool
    if driving <= 0:
        return 0.0
    opening = min(1.0, max(0.0, p.Kp_pool * (p.H_pool_set - H_pool)))
    if H_pool < p.H_pool_set:
        opening = max(opening, 0.02)
    return p.Cv_make * opening * np.sqrt(driving)


def pump_flow(H_pool, pump_tripped, p):
    """循泵从集水池抽水。淹没不足则降额/跳泵。"""
    if pump_tripped or H_pool <= p.H_submerge_min:
        return 0.0
    margin = H_pool - p.H_submerge_min
    if margin < p.submerge_band:
        return p.m_cw0 * (margin / p.submerge_band)
    return p.m_cw0


def loss_flow(Q_cond_kW, m_cw, p):
    evap = Q_cond_kW / p.h_fg / p.rho_water
    return evap + p.blowdown_ratio * evap + p.drift_frac * m_cw


def water_derivs(t, H_pool, pump_tripped, p, t_fault, ramp, Q_cond_kW=None):
    if Q_cond_kW is None:
        Q_cond_kW = p.Q_cond0
    m_cw = pump_flow(H_pool, pump_tripped, p)
    q_loss = loss_flow(Q_cond_kW, m_cw, p)
    q_mu = makeup_flow(t, H_pool, p, t_fault, ramp)
    dHp = (q_mu - q_loss) / p.A_pool
    if H_pool <= 0 and dHp < 0:
        dHp = 0.0
    return dHp, m_cw, q_mu, q_loss


def equilibrate_pool(p, Q_cond_kW=None, dt=1.0, t_settle=3000.0):
    if Q_cond_kW is None:
        Q_cond_kW = p.Q_cond0
    Hp = p.H_pool_set
    for _ in range(int(t_settle / dt)):
        dHp, *_ = water_derivs(0.0, Hp, False, p, t_fault=1e12, ramp=0,
                               Q_cond_kW=Q_cond_kW)
        Hp = min(p.H_pool_set, max(0.0, Hp + dt * dHp))
        if abs(dHp) < 1e-7:
            break
    return Hp


def basin_temp(T_return, m_cw, p):
    T_out = p.T_wetbulb + p.tower_approach_K
    if m_cw <= 0:
        return T_return
    ratio = min(1.0, m_cw / p.m_cw0)
    return T_out + (1.0 - ratio) * 0.5 * max(0.0, T_return - T_out)


def condenser(m_cw_vol, T_cw_in, Q_cond_kW, p):
    if m_cw_vol <= 1e-6:
        return min(50.0, p.p_b_trip_kPa * 3), T_cw_in + 30.0
    C_cw = m_cw_vol * p.rho_water * p.cp_water
    UA = p.UA0 * (m_cw_vol / p.m_cw0) ** p.UA_exp
    eps = min(max(1.0 - np.exp(-UA / C_cw), 1e-3), 0.999)
    T_return = T_cw_in + Q_cond_kW / C_cw
    T_sat = T_cw_in + Q_cond_kW / (eps * C_cw)
    return psat_from_t(T_sat), T_return


def power_derate(p_b, p):
    return max(0.0, 1.0 - p.dPdp_frac_per_kPa * max(0.0, p_b - p.p_b0_kPa))
